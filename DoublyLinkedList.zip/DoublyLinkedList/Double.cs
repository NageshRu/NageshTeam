﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanAgainstGold
{
    class DoublyNode
    {
        public int data;
        public DoublyNode prev, next;
    };
    class Double
    {
        public DoublyNode head;
        public int count;
        public Double()
        {
            head = null;
            count = 0;
        }

        DoublyNode createNode(int data)
        {
            DoublyNode dn = new DoublyNode();
            dn.prev = null;
            dn.data = data;
            dn.next = null;
            count++;
            return dn;
        }
        public void insertAtBegin(int data)
        {
            DoublyNode d = createNode(data);
            if (head == null)
            {
                d.next = head;
                d.prev = head;
                head = d;
            }
            else
            {
                DoublyNode tmp = head;
                d.prev = d;
                d.next = tmp;
                tmp.prev = d;
                head = d;
            }
            
        }
        public void insertAtEnd(int data)
        {
            DoublyNode d = createNode(data);
            if (head == null)
                head = d;
            else
            {
                DoublyNode tmp = head;
                while (tmp.next != null)
                    tmp = tmp.next;
                tmp.next = d;
                d.prev = tmp;
                d.next = null;
            }
        }

        public void insertAtPosition(int data,int pos)
        {
            Console.WriteLine(count);
            if (pos == 1)
                insertAtBegin(data);
            else if (pos == count + 1)
                insertAtEnd(data);
            else
            {
                DoublyNode d = createNode(data);
                DoublyNode pn, cn;
                pn = cn = head;
                for(int i=1;i<pos;i++)
                {
                    pn = cn;
                    cn = cn.next;
                }
                pn.next = d;
                d.prev = pn.next;
                d.next = cn;
                cn.prev = d.next;
            }
        }
        public void deleteAtBegin()
        {
            if (head == null)
                Console.WriteLine("Deletion is Not Possible");
            else
            {
                DoublyNode tmp = head;
                head = head.next;
                Console.WriteLine("Deleted Node is" + tmp.data);
                tmp = null;
            }
        }
        public void deleteAtEnd()
        {
            if(head==null)
                Console.WriteLine("Deletion is Not Possible");
            else
            {
                DoublyNode pn, cn;
                pn = cn = head;
                while (cn.next != null)
                {
                    pn = cn;
                    cn = cn.next;
                }
                if (pn == cn)
                    head = null;
                pn.next = null;
                Console.WriteLine("Deleted Node is" + cn.data);
                cn = null;
            }
        }
        public void deleteByPosition(int pos)
        {
            if (pos == 1)
                deleteAtBegin();
            else if (pos == count)
                deleteAtEnd();
            else
            {
                DoublyNode pn, cn;
                pn = cn = head;
                for(int i=1;i<pos;i++)
                {
                    pn = cn;
                    cn = cn.next;
                }
                pn.next = cn.next;
                Console.WriteLine("Deleted Node is" + cn.data);
                count--;
                cn = null;
            }
        }
        public void findIndexAccurance(int searchdata)
        {
            DoublyNode tmp = head;
            int index=0,flag=0;
            while (tmp != null)
            {
                index++;
                if (tmp.data == searchdata) {
                    flag = 1;
                    Console.WriteLine("Data is Found At this Index :"+index);
                    break;
                }
                tmp = tmp.next;
            }
            if (flag == 0)
                Console.WriteLine("Search Key Not Found");
        }
        public void findIndexAccurance(int searchData,int accurance)
        {
            DoublyNode tmp = head;
            int index = 0,c=0,flag=0;
            while (tmp != null)
            {
                index++;
                if(tmp.data==searchData)
                {
                    flag = 1;
                    c++;
                    if(c==accurance)
                    {
                        Console.WriteLine("Data is Found At this Index :" + index);
                        break;
                    }             
                }
               tmp = tmp.next;
            }
            if (accurance > c)
                Console.WriteLine("Not Possible");
            if(flag==0)
                Console.WriteLine("Search Key not found");
        }
        public void display()
        {
            DoublyNode tmp = head;
            while (tmp != null)
            {
                Console.Write(tmp.data+"\t");
                tmp = tmp.next;
            }
        }
    }
}
