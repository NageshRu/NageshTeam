﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanAgainstGold
{
    class DoublyLinkedList
    {
        static void Main(string[] args)
        {
            Double d = new Double();
            int data, pos;

            while (true)
            {
                Console.WriteLine("\t\t\t\t\t******************Doubly Linked List*********************");
                Console.WriteLine("1.Insert Node At Begin\n2.Insert Node at End\n3.Insert Node at Position\n4.Delete Node At Begin\n5.De" +
                    "lete Node At End\n6.Delete Node By Position\n7.Find Node Data\n8.Find Node data with 1st Accurance\n9.Display Data\n10.Exit\nEnter Your Choice : ");
                int ch = int.Parse(Console.ReadLine());
                if (ch >= 10)
                    System.Environment.Exit(0);
                switch (ch)
                {
                    case 1:
                        Console.WriteLine("Enter Data : ");
                        data = int.Parse(Console.ReadLine());
                        d.insertAtBegin(data);
                        break;
                    case 2:
                        Console.WriteLine("Enter Data : ");
                        data = int.Parse(Console.ReadLine());
                        d.insertAtEnd(data);
                        break;
                    case 3:
                        Console.WriteLine("Enter Data : ");
                        data = int.Parse(Console.ReadLine());
                        do
                        {
                            Console.WriteLine("Enter Position : ");
                            pos = int.Parse(Console.ReadLine());
                        } while (pos <1 || pos > d.count + 1);
                        d.insertAtPosition(data, pos);
                        break;
                    case 4:
                        d.deleteAtBegin();
                        break;
                    case 5:
                        d.deleteAtEnd();
                        break;
                    case 6:
                        do
                        {
                            Console.WriteLine("Enter Position : ");
                            pos = int.Parse(Console.ReadLine());
                        } while (pos < 1 || pos > d.count);
                        d.deleteByPosition(pos);
                        break;
                    case 7:
                        Console.WriteLine("Enter Search Data : ");
                        data = int.Parse(Console.ReadLine());
                        d.findIndexAccurance(data);
                        break;
                    case 8:
                        Console.WriteLine("Enter Search Data : ");
                        data = int.Parse(Console.ReadLine());
                        Console.WriteLine("Enter Which Accurance u want : ");
                        pos = int.Parse(Console.ReadLine());
                        d.findIndexAccurance(data, pos);
                        break;
                    case 9:
                        Console.WriteLine();
                        d.display();
                        break;
                }
            }
        }
    }
}
