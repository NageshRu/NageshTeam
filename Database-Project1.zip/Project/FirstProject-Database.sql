use FirstProject;

create table Author(
	name varchar(255) unique not null,
	address varchar(255) unique not null,
	url varchar(255)
);

create table Publisher(
	name varchar(255) unique not null,
	address varchar(255),
	phone varchar(255),
	url varchar(255)
);

create table Customer(
	email varchar(255) primary key,
	name  varchar(255),
	phone  varchar(255),
	address  varchar(255)
);

create table ShoppingBasket(
	id int primary key,
	customerEmail varchar(255),
	foreign key(customerEmail) references Customer(email)
);

create table Book(
	ISBN varchar(255) primary key,
	publisherName varchar(255) foreign key references Publisher(name),
	authorName varchar(255) foreign key references Author(name),
	authorAddress varchar(255) foreign key references Author(address),
	year int,
	title varchar(255),
	price numeric(19,0) 
);

create table ShoppingBasket_Book(
	shoppingBasketID int foreign key references ShoppingBasket(id),
	bookISBN varchar(255) foreign key references Book(ISBN),
	count int
);

create table Warehouse(
	code int primary key,
	phone varchar(255),
	address varchar(255)
);

create table Warehouse_Book(
	warehouseCode int foreign key references Warehouse(code),
	bookISBN  varchar(255) foreign key references Book(ISBN),
	count int
);