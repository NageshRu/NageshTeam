﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanAgainstGold
{
    class NewCustomer : LendingLone
    {
        public NewCustomer(int custID, int custType) : base(custID, custType)
        {
            if (custType != 1)
            {
                Console.WriteLine("Enter 0 for Old Customer:");
                custType = int.Parse(Console.ReadLine());
            }
        }
        public override float calculateLoan(int custID, int type, float weight, int fineness, int fees = 500)
        {
            int diff = 1, f = 14, amt = 750;
            float totalLoan = 0.0f;
            if (this.custID == custID && this.type == type) { 
            if (fineness > 14 && fineness <= 24)
                diff = fineness - f;
            amt = amt + (diff * 50);
            totalLoan=weight * amt - fees;
            }
            return totalLoan;
        }

        public override float liquidateLoan(int custID, float amountPayable, float liquidationAmt, int fees=100)
        {
            float pendingLoanAmt = amountPayable + liquidationAmt;
            pendingLoanAmt += fees;
            return pendingLoanAmt;
        }
    }
}
