﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanAgainstGold
{
    class LoanOnGoldApp
    {
        static void Main()
        {
            LendingLone ll = new OldCustomer(123,0);
            float loanAmount=ll.calculateLoan(123,0,10,14);
            Console.WriteLine("Loan Amount for Old Customer:" + loanAmount);

            loanAmount = ll.liquidateLoan(123, loanAmount, -1500);
            Console.WriteLine("Liquidate Loan Amount of Old Customer:" + loanAmount);

            LendingLone ll1 = new NewCustomer(321, 1);
            loanAmount = ll1.calculateLoan(321, 1, 15, 22);
            Console.WriteLine("Loan Amount for New Customer:" + loanAmount);

            loanAmount = ll1.liquidateLoan(124, loanAmount, -4000);
            Console.WriteLine("Liquidate Loan Amount of Old Customer:" + loanAmount);
        }
    }
}
