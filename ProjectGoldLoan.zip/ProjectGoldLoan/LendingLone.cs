﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanAgainstGold
{
    abstract class LendingLone
    {
        public int type, custID;

        public LendingLone(int custID,int type)
        {
            this.custID = custID;
            this.type = type;
        }

        public abstract float calculateLoan(int custID, int type, float weight, int fineness,int fees=0);
        public abstract float liquidateLoan(int custID, float amountPayable, float liquidationAmt,int fees=0);//liquidation amount will be pass as a negative number
    }
}
