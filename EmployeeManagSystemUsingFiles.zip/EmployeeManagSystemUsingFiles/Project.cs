﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoanAgainstGold
{
    class Project
    {
        public int pid,deptid,empid;
        public string pname;
        public void setProjectData()
        {
            Console.WriteLine("Enter Project ID:");
            pid = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Project Name:");
            pname = Console.ReadLine();
            Console.WriteLine("Enter Project Manager ID:");
            empid = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Department ID:");
            deptid = int.Parse(Console.ReadLine());
           
        }
        public override string ToString()
        {
            string s = "Project ID:" + pid + "\nProject Name:" + pname + "\nProject Manager ID:" + empid + "\nDepartment ID:" + deptid;
            return s;
        }
        public string getData()
        {
            string s = "Department ID:" + deptid + "\nProject ID:" + pid + "\nProject Name:" + pname + "\nProject Manager ID:" + empid;
            return s;
        }
    }
}
