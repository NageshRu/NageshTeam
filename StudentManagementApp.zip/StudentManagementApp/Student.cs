﻿using System;
using System.Collections.Generic;
namespace LoanAgainstGold
{
    class Student
    {
        public  int stuRollNo { set; get; }
        public int std { set; get; }
        public string sfname { set; get; }
        public string slname{set;get;}
        public string address{set;get;}
        public string gender{set;get;}
        public long mobno { set; get; }
        public int[] marks { set; get; }

        public int getRollNumber()
        {
            Console.WriteLine("Enter Roll No :");
            return (int.Parse(Console.ReadLine()));
        }
        public int getClassNo()
        {
            Console.WriteLine("Enter Class :");
            return (int.Parse(Console.ReadLine()));
        }
        public string getFirstName()
        {
            Console.WriteLine("Enter First Name:");
            return (Console.ReadLine());
        }
        public string getLastName()
        {
            Console.WriteLine("Enter Last Name:");
            return (Console.ReadLine());
        }
        public string getAddress()
        {
            Console.WriteLine("Enter Address:");
            return (Console.ReadLine());
        }
        public long getMobNo()
        {
            Console.WriteLine("Enter Mob No:");
            return (long.Parse(Console.ReadLine()));
        }
        public string getGender()
        {
            Console.WriteLine("Enter Gender:");
            return (Console.ReadLine());
        }
        public int[] getMarks()
        {
            marks = new int[6];
            for (int i = 0; i < marks.Length; i++)
            {
                Console.WriteLine("Subject {0} Marks:", i);
                marks[i] = int.Parse(Console.ReadLine());
            }
            return marks;
        }
        static double getPercentage(int []marks)
        {
            int tot=0;
            foreach (int v in marks)
            {
                tot += v;
            }
            double res= (double)(tot * 100 / 600);
            return res;
        }

        public void getListData(LinkedList<Student> data)
        {
            if (data.Count == 0)
                Console.WriteLine("Database Is Empty");
            else
            {
                foreach (var v in data)
                {
                    Console.WriteLine("\t\t\t***********Student Information************");
                    Console.WriteLine("\n**\t\tRoll No \t: " + v.stuRollNo + "\n**\t\tFirst Name \t: " + v.sfname + "\t\tLast Name \t:" + v.slname + "\n" +
                        "**\t\tAddress\t : " + v.address + "\t\t\tGender\t :" + v.gender + "\n**\t\tMobile No\t : " + v.mobno + "\t\tClass \t : " + v.std);
                    Console.WriteLine("**\t\tSubject Marks\n" +
                        "**\t\t1st Language\t:" + v.marks[0] + "\t\t\t2nd Language\t : " + v.marks[1] + "\n**\t\t3rd Language\t : " + v.marks[2] +
                        "\t\t\tMathematics\t : " + v.marks[3] + "\n**\t\tScience\t : " + v.marks[4] + "\t\t\t\tSocial Science\t : " + v.marks[5] + "\n" +
                        "**\t\tPercentage\t : " + getPercentage(v.marks));
                }
            }
        }
        public void getListData(LinkedList<Student> data,int rollno,int classno)
        {
            bool flag = false;
            foreach (var v in data)
            {
                if (v.stuRollNo == rollno && v.std == classno)
                {
                    flag = true;
                    Console.WriteLine("\t\t\t***********Student Information************");
                    Console.WriteLine("\n**\t\tRoll No \t: " + v.stuRollNo + "\n**\t\tFirst Name \t: " + v.sfname + "\t\tLast Name \t:" + v.slname + "\n" +
                        "**\t\tAddress\t : " + v.address + "\t\t\tGender\t :" + v.gender + "\n**\t\tMobile No\t : " + v.mobno + "\t\tClass \t : " + v.std);
                    Console.WriteLine("**\t\tSubject Marks\n" +
                        "**\t\t1st Language\t:" + v.marks[0] + "\t\t\t2nd Language\t : " + v.marks[1] + "\n**\t\t3rd Language\t : " + v.marks[2] +
                        "\t\t\tMathematics\t : " + v.marks[3] + "\n**\t\tScience\t : " + v.marks[4] + "\t\t\t\tSocial Science\t : " + v.marks[5] + "\n" +
                        "**\t\tPercentage\t : " + getPercentage(v.marks));
                }
            }
            if(flag==false)
                Console.WriteLine("Record is Not Available!!!\nPlease Store Your Information");
        }
        public void updateStudentInfo(LinkedList<Student> data,ref int rollno,ref int classno)
        {
            if (data.Count == 0)
                Console.WriteLine("Record Not Exist");
            foreach(var v in data)
            {
                if (v.stuRollNo == rollno && v.std == classno)
                {
                    v.stuRollNo = getRollNumber();
                    v.sfname = getFirstName();
                    v.slname = getLastName();
                    v.gender = getGender();
                    v.address = getAddress();
                    v.mobno = getMobNo();
                    v.std = getClassNo();
                    v.marks = getMarks();
                }
            }
        }
        public void deleteStudentInfo(LinkedList<Student> data, int rollno, int classno)
        {
            if (data.Count == 0)
                Console.WriteLine("Deletion is Not posible!!\nList is Empty");
            try
            {
                foreach (var v in data)
                {
                    if (v.stuRollNo == rollno && v.std == classno)
                    {
                        data.Remove(v);
                        Console.WriteLine("Deletion is Successful");
                    }
                }
            }
            catch (Exception e) { Console.Write(e); }
        }

        public string generateReport(LinkedList<Student>data,int rollno,int classno)
        {
            string msg=null;
            int count = 0;
            bool flag = false;
            foreach(var v in data)
            {
                if (v.stuRollNo == rollno && v.std == classno)
                {
                    flag = true;
                    foreach(int i in v.marks)
                    {
                        double res=getPercentage(v.marks);
                        if (i < 35)
                            count++;
                        else if (res < 35)
                            msg = "Fail";
                        else if (res >= 35 && res < 60)
                            msg = "Second Class";
                        else if (res >= 60 && res < 75)
                            msg = "First class";
                        else if (res >= 75 && res < 100)
                            msg = "First Class with Distinction";
                    }
                    Console.WriteLine("**\t\tRoll No\t :" +v.stuRollNo+"\t\tClass \t:"+v.std+"\t\tName :"+v.sfname+" "+v.slname+
                        "\n**\t\t1st Language\t:" + v.marks[0] + "\t\t\t2nd Language\t : " + v.marks[1] + "\n**\t\t3rd Language\t : " + v.marks[2] +
                        "\t\t\tMathematics\t : " + v.marks[3] + "\n**\t\tScience\t : " + v.marks[4] + "\t\t\t\tSocial Science\t : " + v.marks[5] + "\n" +
                        "**\t\tPercentage\t : " + getPercentage(v.marks));
                    if (count > 0 && count < 4)
                    {
                        Console.WriteLine("Failed in:" + count);
                        msg = "ATKT";
                    }
                    else if (count >= 4)
                        msg = "Fail";
                }
            }
            if (flag == false)
                Console.WriteLine("Record Is Not Found");
            return msg;
        }
    }  
}