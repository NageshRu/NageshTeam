﻿using System;
using System.Collections.Generic;
namespace LoanAgainstGold
{
    class StudentManagementApp
    {
        static void Main(string[] args)
        {
            Student s = new Student();
            LinkedList<Student> data = new LinkedList<Student>();
            int sRollNo,sstd,rollno,classno;
            string fname, lname, sgender,saddress;
            long smobno;
            int []smarks;
            while (true)
            {
                Console.WriteLine("\n1.Add New Student\t\t\t2.One Student Info" +
                    " \n3.Display All Student Info\t\t4.Update Student Info\n5.Delete Info of One Student \t\t" +
                    "6.Generate Report Card \n7.Exit\nEnter Your Choice :\t\t");
                int opt = int.Parse(Console.ReadLine());
                if (opt >=7)
                    System.Environment.Exit(0);
                switch (opt)
                {
                    case 1:
                        sRollNo = s.getRollNumber();
                        fname = s.getFirstName();
                        lname = s.getLastName();
                        sgender = s.getGender();
                        saddress = s.getAddress();
                        smobno = s.getMobNo();
                        sstd = s.getClassNo();
                        smarks = s.getMarks();

                        if (data.Count == 0)
                            data.AddLast(new Student { stuRollNo = sRollNo, sfname = fname, slname = lname, address = saddress, mobno = smobno, std = sstd, marks = smarks });
                        else
                        {
                            foreach (var v in data)
                            {
                                if (v.stuRollNo == sRollNo)
                                {
                                    Console.WriteLine("Roll Number Should not be Unique");
                                    if (v.std == sstd)
                                    {
                                        Console.WriteLine("What do u want to Change Class or Roll no?\nPlease Enter :");
                                        string scls = Console.ReadLine();
                                        if (scls == "Class")
                                            sstd = s.getClassNo();
                                        else if (scls == "Roll No")
                                            sRollNo = s.getRollNumber();
                                        else
                                            Console.WriteLine("Invalid Choice");
                                    }
                                }
                            }
                            data.AddLast(new Student { stuRollNo = sRollNo, sfname = fname, slname = lname, address = saddress, mobno = smobno, std = sstd, marks = smarks });
                        }
                        break;
                    case 2:
                        Console.WriteLine("\nEnter Student Roll No:");
                        rollno = int.Parse(Console.ReadLine());
                        Console.WriteLine("\nEnter Class :");
                        classno = int.Parse(Console.ReadLine());
                        s.getListData(data, rollno, classno);
                        break;
                    case 3:
                        s.getListData(data);
                        break;
                    case 4:
                        Console.WriteLine("\nEnter Student Roll No:");
                        rollno = int.Parse(Console.ReadLine());
                        Console.WriteLine("\nEnter Class :");
                        classno = int.Parse(Console.ReadLine());
                        s.updateStudentInfo(data,ref rollno,ref classno);
                        break;
                    case 5:
                        Console.WriteLine("\nEnter Student Roll No:");
                        rollno = int.Parse(Console.ReadLine());
                        Console.WriteLine("\nEnter Class :");
                        classno = int.Parse(Console.ReadLine());
                        s.deleteStudentInfo(data, rollno, classno);
                        break;
                    case 6:
                        Console.WriteLine("\nEnter Student Roll No:");
                        rollno = int.Parse(Console.ReadLine());
                        Console.WriteLine("\nEnter Class :");
                        classno = int.Parse(Console.ReadLine());
                        string sresult=s.generateReport(data,rollno,classno);
                        Console.Write("\t\t\t\t Result  : " + sresult);
                        break;

                }
            }
        }
    }
}
