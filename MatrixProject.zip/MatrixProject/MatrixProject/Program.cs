﻿/*
Assignment No:1
Project title:When user enters following keys then perfom  operations on matrix
                1.Up(8) operation
                2.Down(2) operation
                3.Right(6) operation
                4.Left(4) operation
Team Members:
            1.Nagesh Rupnar
            2.Chetan Basavanal
            3.Kusum Kumari

Project Start Date:31/06/2021
Project Completion Date:01/01/2021
*/



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MatrixProject
{
    class Program
    {   
        static int n=0;
        static int[] arr;
        static int currentPosition = 0;

        //Matrix display method,which is having n rows and n columns
        static void generateMatrix(int []arr,int n)
        {
            int sum = n;           
            for (int i = 0; i < arr.Length; i++)
            {
                if (i >= n) { 
                    Console.WriteLine();
                    n += sum;
                }
                Console.Write(arr[i] + "\t");
            }
        }

        static void Main(string[] args)
        {
            Console.Write("Enter user Number : ");
            n = int.Parse(Console.ReadLine());
            arr = new int[n * n];
            for (int i = 0; i < arr.Length; i++)
                arr[i] = 0;
            arr[arr.Length - n] = 1;
            currentPosition = arr.Length - n;
            generateMatrix(arr, n);
            while (true)
            {
                
                Console.WriteLine("\n1.Exit\n8.Up\n2.Down\n4.Left\n6.Right\nEnter Your Option :");
                int opt = int.Parse(Console.ReadLine());
                int sum = n, a=0, b=0; 
                if (opt == 1)
                    System.Environment.Exit(0);
                switch (opt)
                {
                    case 8:
                        if (currentPosition < 0)
                        {
                            Console.WriteLine("We can't Move");
                            break;
                        }
                        if (currentPosition >= 0 && currentPosition >= n)
                        {
                            a = currentPosition - n;
                            b = a + n;
                            arr[a] = 1;
                            arr[b] = 0;
                            currentPosition = a;
                            generateMatrix(arr, n);
                        }
                        else
                        {
                            Console.WriteLine("We can't Move");
                            generateMatrix(arr, n);
                        }
                        break;

                    case 2:
                        if (currentPosition >= 0 && currentPosition < arr.Length - n)
                        {
                            a = currentPosition + n;
                            b = a - n;
                            arr[a] = 1;
                            arr[b] = 0;
                            currentPosition = a;
                            generateMatrix(arr, n);
                        }
                        else
                        {
                            Console.WriteLine("We can't Move");
                            generateMatrix(arr, n);
                        }
                        break;

                    case 6:
                        if (currentPosition>=0 && currentPosition < arr.Length-1)
                        {
                            a = currentPosition + 1;
                            if (a % n == 0)
                            {
                                Console.WriteLine("We can't Move");
                                b = a;
                                arr[a] = 1;
                                arr[b] = 0;
                                generateMatrix(arr, n);
                                break;
                            }
                            else
                            {
                                b = a - 1;
                                arr[a] = 1;
                                arr[b] = 0;
                                currentPosition = a;
                                generateMatrix(arr, n);
                            }
                        }
                        else
                        { 
                            Console.WriteLine("We can't Move");
                            generateMatrix(arr, n);
                        }
                        break;

                    case 4:
                        //Console.WriteLine("Current Position : " + currentPosition);
                        if (currentPosition >= 0 && currentPosition < arr.Length)
                        {
                            if (currentPosition == 0)
                            {
                                currentPosition = 1;
                                Console.WriteLine("We can't Move");
                            }
                            a = currentPosition - 1;
                            if (currentPosition % n == 0)
                            {

                                Console.WriteLine("We can't Move");
                                b = a;
                                arr[a] = 1;
                                arr[b] = 0;
                                generateMatrix(arr, n);
                             
                            }
                            else
                            {
                                b = a + 1;
                                arr[a] = 1;
                                arr[b] = 0;
                                currentPosition = a;
                                generateMatrix(arr, n);
                            }
                            }
                       
                        else
                        {
                            Console.WriteLine("We can't Move");
                            generateMatrix(arr, n);
                        }
                        break;

                    default:
                        System.Environment.Exit(0);
                        break;
                }
            }
            
            
        }
    }
}
